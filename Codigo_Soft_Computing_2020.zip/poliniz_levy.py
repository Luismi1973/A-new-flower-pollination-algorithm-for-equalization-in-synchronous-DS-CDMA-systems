#import numpy as np
#import random

# Parametros para el calculo de la polinizaci�n global y local
# M usuarios, N (bits), num_chips, pop_size, max_iter, p prob de polinizaci�n global


# Funci�n objetivo (error dd estimaci�n)
def objective_func(solution, tx_signal, signatura_i, M, N, num_chips, rayleigh_fading, noise):
    rx_signal_est = np.zeros(N * num_chips)
    
    for user in range(M):
        user_signal = np.zeros(N * num_chips)
        for n in range(N):
            chip_index = n * num_chips
            if solution[user * N + n] == 1:
                user_signal[chip_index:chip_index + num_chips] = signatura_i[user, :] * np.sqrt(1)
            else:
                user_signal[chip_index:chip_index + num_chips] = -signatura_i[user, :] * np.sqrt(1)
        
        rx_signal_est += np.abs(rayleigh_fading[user]) * user_signal
    
    # Error cuadr�tico entre se�al estimada y recibida
    error = np.sum((rx_signal_est + noise - tx_signal) ** 2)
    return error

# Funci�n de polinizaci�n global usando Levy
def levy_flight(Lambda):
    sigma = (np.math.gamma(1 + Lambda) * np.sin(np.pi * Lambda / 2) / 
             (np.math.gamma((1 + Lambda) / 2) * Lambda * 2 ** ((Lambda - 1) / 2))) ** (1 / Lambda)
    
    u = np.random.randn() * sigma
    v = np.random.randn()
    step = u / np.abs(v) ** (1 / Lambda)
    return step

# Polinizaci�n global 
def global_pollination(current_solution, best_solution, Lambda=1.5):
    L = levy_flight(Lambda)
    new_solution = current_solution + L * (current_solution - best_solution)
    
    # valores 0 o 1 (caso binario)
    new_solution = np.round(new_solution).astype(int)
    new_solution = np.clip(new_solution, 0, 1)  # Restringir entre 0 y 1
    return new_solution

# Polinizaci�n local (local pollination step)
def local_pollination(current_solution, population, epsilon=0.1):
    pop_size = len(population)
    
    # Seleccionar dos soluciones aleatorias j y k
    j = random.randint(0, pop_size - 1)
    k = random.randint(0, pop_size - 1)
    
    # Actualizar la soluci�n basada en polinizaci�n local
    new_solution = current_solution + epsilon * (population[j] - population[k])
    
    # Asegurar que los valores sean 0 o 1 (en el caso binario)
    new_solution = np.round(new_solution).astype(int)
    new_solution = np.clip(new_solution, 0, 1)  # Restringir entre 0 y 1
    return new_solution

    
    # Soluciones iniciales
    population = np.random.randint(0, 2, (pop_size, M * N))
    best_solution = population[0, :]
    
    # Simulaci�n del algoritmo
    for iter in range(max_iter):
        for i in range(pop_size):
            if random.random() < p:
                # Polinizaci�n global
                new_solution = global_pollination(population[i], best_solution)
            else:
                # Polinizaci�n local
                new_solution = local_pollination(population[i], population)
            