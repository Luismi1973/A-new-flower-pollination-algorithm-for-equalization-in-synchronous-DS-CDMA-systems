% Particularizacion para canal Rayleigh
% canal con fading tipo Rayleigh
rayleigh_fading = (randn(1, M) + 1i*randn(1, M)) / sqrt(2);

% La señal CDMA será:
tx_signal = zeros(1, N*num_chips); 
for user = 1:M
    user_signal = zeros(1, N*num_chips);
    for n = 1:N
        chip_index = (n-1)*num_chips + 1;
        if bits(user, n) == 1
            user_signal(chip_index:chip_index+num_chips-1) = signatura_i(user, :) * sqrt(energia_i(user));
        else
            user_signal(chip_index:chip_index+num_chips-1) = -signatura_i(user, :) * sqrt(energia_i(user));
        end
    end
    tx_signal = tx_signal + abs(rayleigh_fading(user)) * user_signal;
end

noise = sqrt(sigma2) * randn(1, length(tx_signal));
rx_signal = tx_signal + noise;
