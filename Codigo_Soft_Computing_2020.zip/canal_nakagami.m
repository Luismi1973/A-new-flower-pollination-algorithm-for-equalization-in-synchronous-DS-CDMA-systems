function fading = nakagami_fading_channel(M, N, m)
    % Genera un canal con Fading Nakagami para M usuarios y N símbolos.
       
    if nargin < 3
        m = 2;  % Valor por defecto de m
    end
    
    fading = gamrnd(m, 1/m, M, N);  % Distribución gamma para modelar Nakagami
end
