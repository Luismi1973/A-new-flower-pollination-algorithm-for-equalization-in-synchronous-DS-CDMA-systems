function detected_symbols = decorrelador2(rx_signal, signature_matrix)
    % Detector decorrelador
    R = signature_matrix * signature_matrix';  % Matriz de correlación
    R_inv = inv(R);
    detected_symbols = sign(R_inv * signature_matrix * rx_signal);
end
