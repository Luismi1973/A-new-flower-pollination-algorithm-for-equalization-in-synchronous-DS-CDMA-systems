function detected_symbols = rbf_cdma_mahalanobis_detector(rx_signal, signature_matrix, true_symbols, num_centers)
    % Detector de señales DS/CDMA usando una red RBF con kernels de Mahalanobis.
  
    % Definir los centros
    [M, N] = size(signature_matrix);  % M usuarios, N chips
    centers = kmeans_init(signature_matrix, num_centers);
    
    % Matriz de covarianza para el kernel Mahalanobis
    cov_matrix = cov(signature_matrix);
    inv_cov_matrix = inv(cov_matrix);  % Inversa de la matriz de covarianza
    
    function phi = mahalanobis_kernel(x, c, inv_cov_matrix)
        delta = x - c;
        phi = exp(-delta' * inv_cov_matrix * delta);
    end

    Phi = zeros(M, num_centers);
    for i = 1:M
        for j = 1:num_centers
            Phi(i, j) = mahalanobis_kernel(signature_matrix(i, :), centers(j, :), inv_cov_matrix);
        end
    end
    
    % Pseudoinversa 
    W = pinv(Phi) * true_symbols;
    
    % Estimacion de los símbolos transmitidos
    Phi_test = zeros(M, num_centers);
    for i = 1:M
        for j = 1:num_centers
            Phi_test(i, j) = mahalanobis_kernel(rx_signal(i, :), centers(j, :), inv_cov_matrix);
        end
    end
    
    % Calculo la salida de la red RBF
    output = Phi_test * W;
    
    % Decisión
    detected_symbols = sign(output);
end

% Centros de la RBF usando KMeans
function centers = kmeans_init(signature_matrix, num_centers)
    [~, centers] = kmeans(signature_matrix, num_centers);
end
