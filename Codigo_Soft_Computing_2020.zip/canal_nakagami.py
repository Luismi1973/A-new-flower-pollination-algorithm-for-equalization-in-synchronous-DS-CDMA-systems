
# Canal con Fading Nakagami
def nakagami_fading_channel(M, N, m=2):
    # Genera un canal con fading Nakagami para M usuarios y N símbolos.
    
   fading = np.random.gamma(shape=m, scale=1/m, size=(M, N))
    return fading
