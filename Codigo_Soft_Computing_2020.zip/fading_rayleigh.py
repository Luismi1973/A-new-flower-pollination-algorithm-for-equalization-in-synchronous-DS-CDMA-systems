# Canal con Fading Rayleigh
def rayleigh_fading_channel(M, N):
# Canal con fading Rayleigh para M usuarios y N símbolos.
    
    fading = np.random.rayleigh(scale=1.0, size=(M, N))
    return fading
