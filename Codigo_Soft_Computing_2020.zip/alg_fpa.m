function fpa_2(M,N,num_chips,max_iter,pop_size,p)

% Función objetivo
objective_func = @(x) calc_error(x, tx_signal, signatura_i, M, N, num_chips, rayleigh_fading, noise);

% Inicialización aleatoria de la población (flores) con posibles símbolos
pop = randi([0, 1], pop_size, M*N);  

% Almaceno la mejor solución encontrada
best_sol = pop(1, :);
best_fitness = objective_func(best_sol);

% Algoritmo de polinización de flores (FPA)
for iter = 1:max_iter
    for i = 1:pop_size
        if rand < p
            % Polinización global. Lévy
            L = levy_flight(1, size(pop(i, :)));
            new_sol = pop(i, :) + L .* (pop(i, :) - best_sol);
        else
            % Polinización local. ntercambio soluciones cercanas
            epsilon = rand;
            j = randi([1, pop_size]);
            k = randi([1, pop_size]);
            new_sol = pop(i, :) + epsilon * (pop(j, :) - pop(k, :));
        end
        
        new_sol = round(new_sol);
        new_fitness = objective_func(new_sol);
        
        if new_fitness < objective_func(pop(i, :))
            pop(i, :) = new_sol;
        end
        
        if new_fitness < best_fitness
            best_sol = new_sol;
            best_fitness = new_fitness;
        end
    end
    disp(['Iteración ' num2str(iter) ', Mejor error: ' num2str(best_fitness)]);
end

% Resultado
estimated_bits = reshape(best_sol, [M, N]);
disp('Bits estimados para cada usuario:');
disp(estimated_bits);

%% Función para calcular el error de estimación
function error = calc_error(bits_est, tx_signal, signatura_i, M, N, num_chips, rayleigh_fading, noise)
    rx_signal_est = zeros(1, N*num_chips);
    for user = 1:M
        user_signal = zeros(1, N*num_chips);
        for n = 1:N
            chip_index = (n-1)*num_chips + 1;
            if bits_est((user-1)*N + n) == 1
                user_signal(chip_index:chip_index+num_chips-1) = signatura_i(user, :) * sqrt(1);  % Suponer energía = 1
            else
                user_signal(chip_index:chip_index+num_chips-1) = -signatura_i(user, :) * sqrt(1);
            end
        end
        rx_signal_est = rx_signal_est + abs(rayleigh_fading(user)) * user_signal;
    end
    
    error = sum((rx_signal_est + noise - tx_signal).^2);
end


function L = levy_flight(m, n)
    beta = 1.5;
    sigma = (gamma(1 + beta) * sin(pi * beta / 2) / (gamma((1 + beta) / 2) * beta * 2^((beta - 1) / 2)))^(1 / beta);
    u = randn(m, n) * sigma;
    v = randn(m, n);
    L = u ./ abs(v).^(1 / beta);
end
