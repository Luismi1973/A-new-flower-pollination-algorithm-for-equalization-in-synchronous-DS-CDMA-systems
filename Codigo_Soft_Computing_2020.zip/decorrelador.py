def decorrelating_detector(rx_signal, signature_matrix):
 
    # número de usuarios (M) y longitud de la señal (N)
    M, N = signature_matrix.shape
    
    # matriz de correlación
    R = np.dot(signature_matrix, signature_matrix.T) # (M x M)
    R_inv = np.linalg.inv(R)
    
    # detector decorrelador
    detected_symbols = np.dot(R_inv, np.dot(signature_matrix, rx_signal))
    
    # Decisión 1 o -1 en función del signo
    detected_symbols = np.sign(detected_symbols)
    
    return detected_symbols

#print('Símbolos verdaderos:', true_symbols)
#print('Símbolos detectados:', detected_symbols)
