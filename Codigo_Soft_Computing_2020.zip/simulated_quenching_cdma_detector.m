function detected_symbols = simulated_quenching_cdma_detector(rx_signal, signature_matrix, max_iterations, initial_temp, cooling_rate)
    % Detector DS/CDMA basado en Simulated Quenching.
    %
    % rx_signal: Señal recibida (vector)
    % signature_matrix: Matriz de signaturas (matriz MxN, donde M es el número de usuarios y N el número de chips)
    % max_iterations: Número máximo iteraciones
    % initial_temp: Temperat inicial para el SQ
    % cooling_rate: Tasa de enfriamiento
    % detected_symbols: Vector de símbolos detectados para cada usuario
    
    % Parámetros iniciales
    [M, N] = size(signature_matrix);  % M usuarios, N chips
    detected_symbols = 2 * randi([0, 1], M, 1) - 1;  % (-1 o 1)
    best_symbols = detected_symbols;
    current_temp = initial_temp;  % Temp inicial

    function energy = compute_energy(symbols)
        reconstructed_signal = signature_matrix' * symbols;
        error = norm(rx_signal - reconstructed_signal)^2;
        energy = error;
    end

    % Energía inicial
    current_energy = compute_energy(detected_symbols);
    best_energy = current_energy;
    
    % Alg.Simulated Quenching
    for iter = 1:max_iterations
        perturbation = detected_symbols;
        user_idx = randi(M);  % Seleccionar un usuario al azar
        perturbation(user_idx) = -perturbation(user_idx);  % Cambiar su símbolo
        
        % energía de la nueva solución
        new_energy = compute_energy(perturbation);
 
        if new_energy < current_energy || exp((current_energy - new_energy) / current_temp) > rand()
            detected_symbols = perturbation;
            current_energy = new_energy;
        end
        
        % Actualizar la mejor solución
        if current_energy < best_energy
            best_symbols = detected_symbols;
            best_energy = current_energy;
        end
        
        % Enfriar temp
        current_temp = current_temp * cooling_rate;
        
        fprintf('Iteración %d: Energía actual = %.4f, Mejor energía = %.4f\n', iter, current_energy, best_energy);
    end
    
    % mejor solució
    detected_symbols = best_symbols;
end
