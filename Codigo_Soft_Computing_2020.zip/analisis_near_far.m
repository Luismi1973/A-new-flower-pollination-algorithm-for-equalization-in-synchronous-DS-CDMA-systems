function analisis_near_far(M, N, SNR_dB, power_ratios)
% Análisis del rendimiento near-far para varios detectores


    num_ratios = length(power_ratios);
    errors_corr = zeros(1, num_ratios);
    errors_decorr = zeros(1, num_ratios);
    errors_mmse = zeros(1, num_ratios);

    for i = 1:num_ratios
        [rx_signal, signature_matrix, true_symbols, ~] = simulate_cdma_near_far(M, N, SNR_dB, power_ratios(i));
        noise_var = var(rx_signal) / (10^(SNR_dB/10));

        detected_corr = correlator_detector(rx_signal, signature_matrix);
        detected_decorr = decorrelator_detector(rx_signal, signature_matrix);
        detected_mmse = mmse_detector(rx_signal, signature_matrix, noise_var);

        errors_corr(i) = sum(detected_corr ~= true_symbols) / M;
        errors_decorr(i) = sum(detected_decorr ~= true_symbols) / M;
        errors_mmse(i) = sum(detected_mmse ~= true_symbols) / M;
    end

    % Graficas:
    figure;
    plot(power_ratios, errors_corr, '-o', 'DisplayName', 'Correlador');
    hold on;
    plot(power_ratios, errors_decorr, '-x', 'DisplayName', 'Decorrelador');
    plot(power_ratios, errors_mmse, '-s', 'DisplayName', 'MMSE');
    xlabel('Relación de Potencias (Near/Far)');
    ylabel('Tasa de Error de Simbolo');
    legend show;
    title('Rendimiento Near-Far en Diferentes Esquemas de Detección');
    grid on;
end
