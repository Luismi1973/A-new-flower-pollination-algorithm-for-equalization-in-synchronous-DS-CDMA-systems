#import numpy as np
#import matplotlib.pyplot as plt

def generate_signature_matrix(M, N):
    return 2 * np.random.randint(0, 2, (M, N)) - 1  # {-1, 1}

def simulate_cdma_system(M, N, Eb_No_dB):
    # Matriz de signaturas
    signature_matrix = generate_signature_matrix(M, N)
    
    # Símbolos transmitidos por cada usuario
    true_symbols = 2 * np.random.randint(0, 2, M) - 1  # {-1, 1}

    Eb_No_linear = 10**(Eb_No_dB / 10)
    noise_var = 1 / (2 * Eb_No_linear)
    
    # Señal transmitida
    tx_signal = np.dot(true_symbols, signature_matrix)

    # Ruido AWGN
    noise = np.sqrt(noise_var) * np.random.randn(N)

    # Señal recibida
    rx_signal = tx_signal + noise
    
    return rx_signal, signature_matrix, true_symbols

def correlator_detector(rx_signal, signature_matrix):
    detected_symbols = np.dot(signature_matrix, rx_signal)
    return np.sign(detected_symbols)

def calculate_ber(true_symbols, detected_symbols):
    return np.sum(true_symbols != detected_symbols) / len(true_symbols)

def simulate_ber_vs_users(Eb_No_dB, N, max_users):
    ber_list = []
    user_list = range(1, max_users + 1)

    for M in user_list:
        rx_signal, signature_matrix, true_symbols = simulate_cdma_system(M, N, Eb_No_dB)
        detected_symbols = correlator_detector(rx_signal, signature_matrix)
        ber = calculate_ber(true_symbols, detected_symbols)
        ber_list.append(ber)

    return user_list, ber_list

def plot_ber_vs_users(Eb_No_dB, N, max_users):
    user_list, ber_list = simulate_ber_vs_users(Eb_No_dB, N, max_users)

    plt.plot(user_list, ber_list, 'o-', label=f'Eb/No = {Eb_No_dB} dB')
    plt.xlabel('Número de Usuarios Activos')
    plt.ylabel('Tasa de Error de Bit (BER)')
    plt.title('BER vs Número de Usuarios Activos en DS/CDMA')
    plt.grid(True)
    plt.legend()
    plt.show()


