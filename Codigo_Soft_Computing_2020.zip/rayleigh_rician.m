function fading = rician_fading_channel(M, N, K)
    % Genera un canal con Fading Rician para M usuarios y N símbolos.
  
    
    if nargin < 3
        K = 6;  % Valor por defecto para el factor K
    end
    
    los = sqrt(K / (K + 1));              % Componente LoS
    nlos = sqrt(1 / (K + 1)) * randn(M, N);  % Componente no-LoS
    
    fading = los + nlos;
end
