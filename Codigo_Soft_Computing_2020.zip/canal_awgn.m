function rx_signal = awgn_channel(tx_signal, snr_db)
    % Genera un canal AWGN, agregando ruido blanco gaussiano a la señal transmitida.
    % rx_signal: Señal recibida con ruido AWGN añadido.
    
    snr_linear = 10^(snr_db / 10);             
    signal_power = mean(abs(tx_signal).^2);      
    noise_power = signal_power / snr_linear;     
    noise = sqrt(noise_power / 2) * randn(size(tx_signal));  
    
    rx_signal = tx_signal + noise;               % Señal recibida con ruido
end
