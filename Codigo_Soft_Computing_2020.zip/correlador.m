function detected_symbols = correlador(rx_signal, signature_matrix)
    % Detector de correlación
    detected_symbols = sign(signature_matrix * rx_signal);
end
