function fading = rayleigh_fading_channel(M, N)
    % Genera un canal con Fading Rayleigh para M usuarios y N símbolos.
       
    fading = raylrnd(1, M, N);  % Escala parámetro = 1
end
