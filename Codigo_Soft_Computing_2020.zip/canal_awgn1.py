# Canal AWGN (Additive White Gaussian Noise)
def awgn_channel(tx_signal, snr_db):
  #  Genera canal AWGN

    snr_linear = 10 ** (snr_db / 10)
    signal_power = np.mean(np.abs(tx_signal) ** 2)
    noise_power = signal_power / snr_linear
    noise = np.sqrt(noise_power / 2) * np.random.normal(size=tx_signal.shape)
    
    rx_signal = tx_signal + noise
    return rx_signal
