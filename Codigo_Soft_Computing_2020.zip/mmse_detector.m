function detected_symbols = mmse_detector(rx_signal, signature_matrix, noise_var)
    % Detector MMSE
    R = signature_matrix * signature_matrix';
    M = length(signature_matrix(:,1));
    R_mmse = R + noise_var * eye(M);
    detected_symbols = sign(inv(R_mmse) * signature_matrix * rx_signal);
end
