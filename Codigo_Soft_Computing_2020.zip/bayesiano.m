function detected_symbols = bayesian_cdma_detector(rx_signal, signature_matrix, prior_probs, noise_var)
    % Detector DS/CDMA mediante algoritmo bayesiano.
  
    [M, N] = size(signature_matrix);  % M usuarios, N chips por usuario
    symbols = [-1, 1];  % {1, -1}

    % Inicialización 
    post_probs = zeros(M, length(symbols));  % Probabilidades a posteriori decada símbolo

    for i = 1:M
        for j = 1:length(symbols)
            cond_prob = conditional_probab(rx_signal, signature_matrix(i, :), symbols(j), noise_var);
            post_probs(i, j) = cond_prob * prior_probs(j);
        end
        
        % Normalizacion
        post_probs(i, :) = post_probs(i, :) / sum(post_probs(i, :));
        
        % Decisión
        [~, max_idx] = max(post_probs(i, :));
        detected_symbols(i) = symbols(max_idx);
    end
end


function cond_prob = conditional_probab(rx_signal, user_signature, symbol, noise_var

    % Señal transmitida esperada
    expected_signal = user_signature * symbol;
    
    % fdp
    cond_prob = (1 / sqrt(2 * pi * noise_var)) * exp(-norm(rx_signal - expected_signal)^2 / (2 * noise_var));
end
