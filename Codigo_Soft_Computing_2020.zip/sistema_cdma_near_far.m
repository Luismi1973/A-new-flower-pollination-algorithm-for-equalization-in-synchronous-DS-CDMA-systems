function [rx_signal, signature_matrix, true_symbols, power_levels] = sistema_cdma_near_far(M, N, SNR_dB, power_ratio)
    % Simula un sistema DS/CDMA con el efecto near-far.
  
    % Matriz de signaturas (M usuarios, N chips)
    signature_matrix = 2 * randi([0, 1], M, N) - 1;  % {-1, 1}

    % Símbolos transmitidos
    true_symbols = 2 * randi([0, 1], M, 1) - 1;

    % Niveles de potencia de cada usuario (near-far)
    power_levels = ones(M, 1);
    power_levels(1) = power_ratio;  % El usuario cercano tiene más potencia

    % Señal transmitida
    transmitted_signal = signature_matrix' * (true_symbols .* sqrt(power_levels));

    SNR_linear = 10^(SNR_dB / 10);
    
    % Añadir ruido gaussiano blanco aditivo 
    noise_variance = var(transmitted_signal) / SNR_linear;
    noise = sqrt(noise_variance) * randn(N, 1);

    % Señal recibida
    rx_signal = transmitted_signal + noise;
end
