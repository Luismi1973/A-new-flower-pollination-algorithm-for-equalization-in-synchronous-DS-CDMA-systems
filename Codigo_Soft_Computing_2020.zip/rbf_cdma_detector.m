function detected_symbols = rbf_cdma_detector(rx_signal, signature_matrix, true_symbols, num_centers)
    % Detector de señales DS/CDMA usando una red RBF con kernels tipo euclideo
    %
    % Definicion de los centros (utilizamos KMeans)
    [M, N] = size(signature_matrix);  % M usuarios, N chips
    centers = kmeans_init(signature_matrix, num_centers);  
    
    % Calcula los radios usando la distancia media entre centros
    distances = pdist(centers);
    spread = mean(distances) / sqrt(2); 
    
    % Función de activación de la capa RBF
    function phi = rbf_kernel(x, c, spread)
        % Kernel gaussiano de tipo euclideo
        phi = exp(-norm(x - c)^2 / (2 * spread^2));
    end

    Phi = zeros(M, num_centers);
    for i = 1:M
        for j = 1:num_centers
            Phi(i, j) = rbf_kernel(signature_matrix(i, :), centers(j, :), spread);
        end
    end
    
    % Pseudoinversa 
    W = pinv(Phi) * true_symbols;
    
    % Estima símbolos transmitidos 
    Phi_test = zeros(M, num_centers);
    for i = 1:M
        for j = 1:num_centers
            Phi_test(i, j) = rbf_kernel(rx_signal(i, :), centers(j, :), spread);
        end
    end
    
    % Calculo la salida 
    output = Phi_test * W;
    
    % Decisión 
    detected_symbols = sign(output);
end

% Centros de la RBF usando KMeans
function centers = kmeans_init(signature_matrix, num_centers)
    [~, centers] = kmeans(signature_matrix, num_centers);
end
