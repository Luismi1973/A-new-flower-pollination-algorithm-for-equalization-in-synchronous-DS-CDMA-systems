# Canal con Fading Rician
def rician_fading_channel(M, N, K=6):
  #  Genera un canal con fading Rician para M usuarios y N símbolos.
    
  # Componentes LoS y NLoS
    los = np.sqrt(K / (K + 1))
    nlos = np.sqrt(1 / (K + 1)) * np.random.normal(0, 1, (M, N))
    
    fading = los + nlos
    return fading
