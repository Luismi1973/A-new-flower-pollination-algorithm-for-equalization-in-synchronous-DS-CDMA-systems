function mod_canal_DSCDMA(M,N,Eb_N0_dB,fc,fs,Tc,num_chips,Eb)

% M: Número de usuarios
% N: Num bits transmitidos por cada usuario
% Eb_N0_dB: Relación señal a ruido en dB
% fc  Frecuencia de portadora
% fs: Frecuencia de muestreo
% Tc: periodo de chip
% num_chips
% Eb: Energía bit 

% Matrices de usuarios
bits = randi([0, 1], M, N);  % Bits aleatorios transmitidos
energia_i = rand(1, M) * Eb; 
a_i = rand(1, M);  % Coefs de fading (flat fading)
signatura_i = 2*randi([0, 1], M, num_chips) - 1;

Eb_N0 = 10^(Eb_N0_dB/10);
sigma2 = 1/(2*Eb_N0);  % Varianza ruido

% Generamos señal CDMA para cada usuario
tx_signal = zeros(1, N*num_chips);  
for user = 1:M
    user_signal = zeros(1, N*num_chips);
    for n = 1:N
        chip_index = (n-1)*num_chips + 1;
        if bits(user, n) == 1
            user_signal(chip_index:chip_index+num_chips-1) = signatura_i(user, :) * sqrt(energia_i(user));
        else
            user_signal(chip_index:chip_index+num_chips-1) = -signatura_i(user, :) * sqrt(energia_i(user));
        end
    end
    % Aplicar el flat fading y sumar la señal
    tx_signal = tx_signal + a_i(user) * user_signal;
end

% ruido 
noise = sqrt(sigma2) * randn(1, length(tx_signal));
rx_signal = tx_signal + noise;
